# nodejs-with-firebase

This is the simple demo of nodejs connect with firebase. Complete the CRUD operation
